<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&amp;display=swap" rel="stylesheet"/>
    <style>
/* Base styles */
/* Base styles */
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
}

.sidebar {
    width: 250px;
    background-color: #4A3AFF;
    color: white;
    padding: 10px;
    height: 100vh;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
}

.sidebar img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    margin-bottom: 10px;
}

.sidebar h1 {
    font-size: 24px;
    margin: 10px 0;
}

.sidebar a {
    color: white;
    text-decoration: none;
    font-size: 15px;
    margin-bottom: 10px;
    display: block;
}

.sidebar a:hover {
    text-decoration: underline;
}

.sidebar .bottom-links a {
    display: flex;
    align-items: center;
    margin-top: 10px;
}

.sidebar .bottom-links a i {
    margin-right: 10px;
}

.main-content {
    flex-grow: 1;
    background-color: #F5F5F5;
    padding: 20px;
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header .user-info {
    display: flex;
    align-items: center;
}

.header .user-info .notification {
    display: flex;
    align-items: center;
    margin-right: 10px;
    margin-left: 1300px;
}

.header .user-info .vertical-rule {
    border-left: 1px solid #E0E0E0;
    height: 40px;
    margin: 0 20px;
}

.header .user-info img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.header .user-info span {
    font-size: 16px;
}

.table-container {
    background-color: white;
    border-radius: 5px;
    padding: 20px;
    position: relative;
}

.table-container .search-bar-container {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
}

.table-container .search-bar-container .create-btn {
    margin-right: 20px;
    background-color: #4A3AFF;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
}

.table-container .search-bar-container .search-bar {
    display: flex;
    align-items: center;
    background-color: #EDEDED;
    padding: 10px;
    border-radius: 5px;
    flex-grow: 1;
    cursor: pointer;
}

.table-container .search-bar-container .search-bar input {
    border: none;
    background: none;
    outline: none;
    margin-left: 10px;
    font-size: 16px;
    flex-grow: 1;
}

/* Optional: Ensure the input takes up full width of the search bar */
.table-container .search-bar-container .search-bar input:focus {
    outline: none;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th, table td {
    padding: 15px;
    text-align: left;
}

table th {
    background-color: #E0E0FF;
}

table tr:nth-child(even) {
    background-color: #F9F9F9;
}

table tr:hover {
    background-color: #F1F1F1;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.pagination a {
    color: #4A3AFF;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.pagination .page-number {
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #E0E0FF;
    border-radius: 50%;
    margin: 0 5px;
}

.pagination .page-number.active {
    background-color: #4A3AFF;
    color: white;
}

hr {
    border: 0;
    height: 1px;
    background: #E0E0E0;
    margin: 20px 0;
}

/* Responsive styles */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }

    .main-content {
        margin-left: 200px;
    }

    .header .user-info {
        margin-right: 20px; /* Adjust if needed */
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: static;
    }

    .main-content {
        margin-left: 0;
        padding: 10px;
    }

    .header .user-info {
        margin-right: 0;
    }

    .table-container {
        padding: 10px;
    }

    .table-container .search-bar-container {
        flex-direction: column;
        align-items: flex-start;
    }

    .table-container .search-bar-container .create-btn {
        margin-right: 0;
        margin-bottom: 10px;
    }

    .table-container .search-bar-container .search-bar {
        width: 100%;
    }

    table th, table td {
        padding: 10px;
    }

    .pagination a, .pagination .page-number {
        font-size: 14px;
        margin: 0 5px;
    }
}

@media (max-width: 480px) {
    .sidebar {
        width: 100%;
        padding: 10px;
    }

    .sidebar img {
        width: 60px;
        height: 60px;
    }

    .sidebar h1 {
        font-size: 20px;
    }

    .header .user-info span {
        font-size: 14px;
    }

    .table-container {
        padding: 5px;
    }

    .table-container .search-bar-container .create-btn {
        padding: 8px 16px;
    }

    table th, table td {
        padding: 8px;
    }

    .pagination a, .pagination .page-number {
        font-size: 12px;
        margin: 0 3px;
    }
}

    </style>
</head>
<body>
    <div class="sidebar">
        <img src="../Capstone/logo/logo.png" alt="Logo"><br><br><br><br><br>
        <a href="#">Student Records</a><br>
        <a href="parent.php">Parent Records</a><br>
        <a href="#">Admin/Staff Records</a><br>
        <a href="#">Pick-Up Records</a><br>
        <a href="#">Events</a><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="user-info">
                <div class="notification">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="vertical-rule"></div>
                <div class="profile">
                    <img alt="User profile picture" height="40" src="https://oaidalleapiprodscus.blob.core.windows.net/private/org-Hh5RPsKhtBPsWCFSiEKnUJ6x/user-8qgiVpCV0U0b7zDjfFInHgjl/img-UaqtED2tWdF8Jj5BdVptvrvZ.png?st=2024-09-08T03%3A49%3A50Z&amp;se=2024-09-08T05%3A49%3A50Z&amp;sp=r&amp;sv=2024-08-04&amp;sr=b&amp;rscd=inline&amp;rsct=image/png&amp;skoid=d505667d-d6c1-4a0a-bac7-5c84a87759f8&amp;sktid=a48cca56-e6da-484e-a814-9c849652bcb3&amp;skt=2024-09-07T23%3A47%3A39Z&amp;ske=2024-09-08T23%3A47%3A39Z&amp;sks=b&amp;skv=2024-08-04&amp;sig=18zzyGV2lWaM/BQ7/LoacKemQW7r9eD1vJOq3I7Ssss%3D" width="40"/>
                    <span>Admin Admin</span>
                </div>
            </div>
        </div>
        <hr/>
        <div class="table-container">
            <div class="search-bar-container">
                <div class="search-bar">
                    <i class="fas fa-filter"></i>
                    <input placeholder="Search" type="text"/>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Grade &amp; Section</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>0123436878</td>
                        <td>Jerome Warren</td>
                        <td>Grade 3 - Sunflower</td>
                        <td>Aurora Blvd. Cubao Quezon City</td>
                        <td><i class="fas fa-pen"></i> <i class="fas fa-trash"></i> <i class="fas fa-eye"></i></td>
                    </tr>
                    <!-- Repeat rows as needed -->
                </tbody>
            </table>
        </div>
        <hr/>
        <div class="pagination">
            <a href="#">Prev</a>
            <div class="page-number active">1</div>
            <div class="page-number">2</div>
            <div class="page-number">3</div>
            <div class="page-number">4</div>
            <div class="page-number">5</div>
            <a href="#">Next</a>
        </div>
    </div>
</body>
</html>
