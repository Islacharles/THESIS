<?php
include 'connection.php';

$parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;

if ($parent_id > 0) {
    $sql = "SELECT c.*, a.fullname AS child_teacher_name FROM child_acc c 
            JOIN admin_staff a ON c.child_teacher = a.id 
            WHERE c.parent_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $parent_id);
    
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $children = [];
        while ($row = $result->fetch_assoc()) {
            // Fetch authorized persons from another table or set here if it's part of the data
            $row['authorized_persons'] = []; // You may need to replace this with actual data retrieval
            $children[] = $row;
        }

        header('Content-Type: application/json');
        echo json_encode($children);
    } else {
        header('Content-Type: application/json');
        echo json_encode(["error" => "Database query failed."]);
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(["error" => "Invalid parent ID."]);
}

// Close the database connection
$stmt->close();
$conn->close();
?>