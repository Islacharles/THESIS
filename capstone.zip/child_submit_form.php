<?php
include 'connection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . htmlspecialchars($conn->connect_error)]));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $parent_id = trim($_POST['parent_id']);
    $child_name = trim($_POST['child_name']);
    $child_id = trim($_POST['child_id']);
    $child_teacher = trim($_POST['child_teacher']);
    $child_age = trim($_POST['child_age']);
    $child_grade = trim($_POST['child_grade']);
    $child_section = trim($_POST['child_section']);
    $child_address = trim($_POST['child_address']);

    // Check if parent_id is set and valid
    if (empty($parent_id) || !is_numeric($parent_id)) {
        die(json_encode(['success' => false, 'message' => 'Invalid parent ID']));
    }

    // Handle the image upload
    $image_data = null;
    if (isset($_FILES['child_image']) && $_FILES['child_image']['error'] == UPLOAD_ERR_OK) {
        $child_image = $_FILES['child_image']['tmp_name'];
        $image_data = file_get_contents($child_image);
    } else {
        die(json_encode(['success' => false, 'message' => 'Image upload error: ' . htmlspecialchars($_FILES['child_image']['error'])]));
    }

    $child_sql = "INSERT INTO child_acc (parent_id, child_name, child_id, child_teacher, child_age, child_grade, child_section, child_address, child_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($child_sql);

    if ($stmt === false) {
        die(json_encode(['success' => false, 'message' => "Database prepare failed: " . htmlspecialchars($conn->error)]));
    }

    // Adjust bind_param types
    // For the last parameter (image data), we bind it as a string
    $stmt->bind_param("ississsss", $parent_id, $child_name, $child_id, $child_teacher, $child_age, $child_grade, $child_section, $child_address, $image_data);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error inserting child information: ' . htmlspecialchars($stmt->error)]);
    }

    $stmt->close();
}

$conn->close();
?>
